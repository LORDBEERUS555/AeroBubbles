# Building AeroBubbles on your laptop

**This archive contains editable Android Studio source, not an APK.** We could not compile an APK in the creation environment (Android SDK/build tools are absent). This source has not been tested on a physical Pixel 10.

1. Install Android Studio on Windows, macOS or Linux. Install Android SDK Platform 35 via the SDK Manager, and Android SDK Build-Tools.
2. Extract this ZIP and select **Open** in Android Studio. Choose the `AeroBubbles_AndroidStudio` folder.
3. If Android Studio prompts for a Gradle installation or wrapper, use **Gradle 8.9** (the project includes a wrapper *properties* file, but not the wrapper JAR). You can also install Gradle 8.9 and run `gradle assembleDebug` from the project root. Sync the project, allowing Android Studio to fetch Android Gradle Plugin 8.7.3.
4. **Build → Build APK(s)** (or `gradle assembleDebug`). APK should be at `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy the APK to your Pixel 10. Install it after enabling permission for installing apps from the file manager you used.
6. Open Lawnchair → Home settings → General → Icon style → Themed icon source → AeroBubbles. Enable themed icons.
7. To use shiny blue/green icons instead, set **Icon pack** to AeroBubbles, disable **Themed icons**, and disable **Tint with accent color**.

**Important:** Themed sources are monochrome, so no glossy blue gradient in themed mode. Full-color icons are supplied as the standard pack. Android may warn about installing an app from outside Play; only install an APK you built yourself. No network permission is requested by AeroBubbles. No trackers or external dependencies except Android Gradle Plugin at build time.

**Coverage:** 36 package mappings for themed mode, and standard ADW `appfilter.xml` component mappings for many popular apps. Android launch activity class names change, so some standard icons may need manual assignment. Themed map matches by package and is generally more reliable. Some apps / Lawnchair versions may not theme correctly; known reports affect Pixel 10-era Lawnchair versions.

**Customizing:** Change images in `app/src/main/res/drawable-nodpi`, package mappings in `res/xml/grayscale_icon_map.xml`, activity mappings in `res/xml/appfilter.xml`, and icons in `artwork/svg` (editable). To add a new icon, add its PNG file, mapping to `grayscale_icon_map.xml`, and `appfilter.xml` as applicable.
