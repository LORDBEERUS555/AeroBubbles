# AeroBubbles — Frutiger Aero for Lawnchair 🫧

A tiny editable Android icon pack project, with **two** icon modes:

- **Themed icon source**: 36 blue-bubble-inspired **monochrome** glyphs. Lawnchair applies its own theme tint. Uses `app.lawnchair.icons.THEMED_ICON` intent and `res/xml/grayscale_icon_map.xml`.
- **Regular ADW icon pack**: 36 glossy gradient **Frutiger Aero** orb icons. Uses `appfilter.xml` and `drawable.xml` with `org.adw.ActivityStarter.THEMES` intent.

The glossy colors are the best match for the user's Messenger-era blue glass person reference. Icons are original artwork, not copies of Windows or third-party brand logos. App icon symbols are generalized for broad compatibility.

See [BUILDING.md](BUILDING.md) for Android Studio steps. Source is provided, **not a pre-built installable APK**.

## Licensing

Original artwork and code in this project can be modified and used personally or shared under MIT license (see LICENSE). Third-party names are used only to describe package compatibility. No logos or fonts from Microsoft, Google, Discord etc. are included.

## Known limitations

- Themed icon source mode cannot preserve multicolor glossy gradients.
- Lawnchair icon packs can require correct activity class mappings; some launcher versions and third-party app upgrades may affect coverage.
- Build/install has not been verified on a physical phone.
