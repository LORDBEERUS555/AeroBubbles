package com.aerobubbles.pack;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;

public class IconPackActivity extends Activity {
    private TextView label(String s, int sp, int color, boolean bold) {
        TextView tv=new TextView(this);
        tv.setText(s);tv.setTextSize(sp);tv.setTextColor(color);
        if(bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setPadding(0,14,0,14);return tv;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout=new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(35,45,35,35);layout.setBackgroundColor(Color.rgb(231,250,255));
        ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.aero_contacts);
        LinearLayout.LayoutParams imageParams=new LinearLayout.LayoutParams(180,180);
        layout.addView(icon,imageParams);
        layout.addView(label("AeroBubbles  🫧",28,Color.rgb(8,87,172),true));
        layout.addView(label("Frutiger Aero icons made for Lawnchair",16,Color.rgb(39,105,135),false));
        layout.addView(label("THEMED ICON SOURCE",18,Color.rgb(8,87,172),true));
        layout.addView(label("Lawnchair Home settings → General → Icon style → Themed icon source → AeroBubbles. Enable Themed icons. Lawnchair will recolor the monochrome bubble outlines.",16,Color.rgb(25,61,90),false));
        layout.addView(label("FULL-COLOR BUBBLES",18,Color.rgb(8,87,172),true));
        layout.addView(label("For the shiny blue/green orbs: in Icon style, select the AeroBubbles icon pack and turn off Tint with accent color / Themed icons.",16,Color.rgb(25,61,90),false));
        layout.addView(label("Coverage: 36 common apps. For apps not mapped, your original icon may appear. You can manually assign glossy icons in Lawnchair.",14,Color.rgb(52,99,122),false));
        ScrollView scroll=new ScrollView(this);scroll.addView(layout);setContentView(scroll);
    }
}
