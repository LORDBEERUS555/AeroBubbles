# Build AeroBubbles as an installable APK

The project contains 36 glossy and monochrome icons. This ZIP contains **source code**, not an installable APK. It has **not been built or tested on a Pixel 10**.

## Option A — easiest with Android Studio on your Windows laptop

1. Download and install Android Studio from https://developer.android.com/studio .
2. Extract the ZIP. In Android Studio select **Open** and choose this extracted `AeroBubbles_Easy_Build` folder (the one with `settings.gradle`).
3. Trust the project only if you are comfortable with the source. Allow Android Studio to install the Android SDK/platform 35 and sync Gradle 8.9 as prompted. This may require several GB of downloads.
4. In the **Build** menu, choose **Generate Bundle(s) / APK(s) > Generate APK(s)** (some versions say **Build Bundle(s) / APK(s) > Build APK(s)**). Keep the **debug** build variant.
5. Use the completion notification's **locate** link. The resulting file is `app\build\outputs\apk\debug\app-debug.apk`.
6. Transfer `app-debug.apk` to your Pixel via USB or Drive. Open it in Files on your phone and allow 'Install unknown apps' for your file manager if Android prompts you.
7. In Lawnchair, open **Home settings > General > Icon style**. For full-color shine choose **Icon pack: AeroBubbles** and disable themed icons; for monochrome tint choose **Themed icon source: AeroBubbles** and enable themed icons. App mappings vary by version; some icons may need manual assignment.

### If Gradle sync complains about missing wrapper

This project includes `gradle/wrapper/gradle-wrapper.properties` but not the wrapper JAR/scripts. Android Studio often uses wrapper *properties* directly. If it asks for a wrapper JAR and won't sync, use the GitHub Actions method below, which uses hosted Gradle and **does not require wrapper files**. If you want a local command-line build, first generate wrapper files with a trusted local Gradle 8.9 installation.

## Option B — free cloud build using GitHub (no Android Studio required)

1. Open https://github.com/new while signed in, create an empty repository, e.g. `AeroBubbles`. Choose your visibility (private is fine). Do **not** initialize with a README or .gitignore.
2. On your Windows computer, unzip the package. On your new repository, choose **uploading an existing file**. Drag the **contents** of `AeroBubbles_Easy_Build` (all files/folders, including the hidden `.github` folder) into GitHub's upload area and commit to `main`.
3. Open your repository's **Actions** tab. If needed, enable Actions. The **Build AeroBubbles APK** workflow will start on the push to `main`; otherwise choose it then press **Run workflow**.
4. Open the successful workflow run, scroll to **Artifacts**, and download **AeroBubbles-APK**. Unzip that artifact to find `app-debug.apk`.
5. Transfer the APK to your phone and follow option A step 6-7 above.

GitHub Actions workflows run in a third-party hosted environment; never upload credentials or private files with the source project.

## Safety / limitations

- This is a personal debug build signed with a development key. Android may warn about installing an APK outside Google Play.
- A regular icon pack and themed icon source are different modes. **Themed mode removes the glossy color effect.**
- The APK can be uninstalled like any normal Android app.
- No Internet permission is included in the manifest.
- The 36 built-in icon drawings are original and generic. Package/activity mappings are not guaranteed to match every installed app, and the launcher may display default icons for unsupported apps.
